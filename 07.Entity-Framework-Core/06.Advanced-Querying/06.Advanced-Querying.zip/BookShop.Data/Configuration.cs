﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=.;Database=BookShop;User Id=sa;Password=Mitko875486123";

        //Server=.;Database=BookShop;Integrated Security = True;
    }
}
